'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const EventEmitter = require('events');

const PORT = Number(process.argv[2] || process.env.PORT || 3000);
const ROOT = __dirname;
const W = 960;
const H = 540;
const TICK = 1000 / 30;
const SNAPSHOT = 1000 / 15;
const MAX_PLAYERS = 4;
const ASSET = 'gameassets/';
const HAT_IDS = new Set(['none','hat','crown','monster','number1','soldier','wizard']);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8'
};

const WEAPONS = [
  {
    id: 'knife', name: 'Knife', rarity: 'Comune', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/common/knife.png', behavior: 'slash', damage: 30, cooldown: 0.34, range: 68, cone: 100,
    manaCost: 0, stats: { speedPct: 8 }, desc: 'Colpo corto e rapido. Ottima per muoversi aggressivi tra i nemici.'
  },
  {
    id: 'shortsword', name: 'Short Sword', rarity: 'Comune', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/common/shortsword.png', behavior: 'slash', damage: 46, cooldown: 0.50, range: 92, cone: 110,
    manaCost: 0, stats: { attackPct: 6 }, desc: 'Arma iniziale bilanciata, stabile e facile da controllare.'
  },
  {
    id: 'axe', name: 'Axe', rarity: 'Comune', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/common/axe.png', behavior: 'slash', damage: 76, cooldown: 0.96, range: 86, cone: 125, knock: 34,
    manaCost: 0, stats: { attackPct: 12, speedPct: -5 }, desc: 'Lenta e pesante, con forte knockback. Ideale per aprire spazio.'
  },
  {
    id: 'pistol', name: 'Pistol', rarity: 'Comune', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/common/pistol.png', behavior: 'projectile', damage: 18, cooldown: 0.54, bulletSpeed: 430, pierce: 1,
    manaCost: 0, stats: { cooldownPct: 5 }, desc: 'Arma precisa e regolare, buona per iniziare una run a distanza.'
  },
  {
    id: 'bow', name: 'Bow', rarity: 'Comune', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/common/bow.png', behavior: 'projectile', damage: 36, cooldown: 0.98, bulletSpeed: 340, pierce: 2,
    manaCost: 0, stats: { pickupPct: 10 }, desc: 'Arco lento ma potente, capace di perforare più bersagli.'
  },
  {
    id: 'pebblegun', name: 'Pebble Gun', rarity: 'Comune', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/common/pebblegun.png', behavior: 'projectile', damage: 5, cooldown: 0.13, bulletSpeed: 455, pierce: 1,
    manaCost: 0, stats: { bulletSpeedPct: 8 }, desc: 'Fuoco rapidissimo a basso danno, efficace contro bersagli fragili.'
  },
  {
    id: 'longsword', name: 'Long Sword', rarity: 'Comune', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/common/longsword.png', behavior: 'slash', damage: 58, cooldown: 0.70, range: 118, cone: 105,
    manaCost: 0, stats: { attackPct: 8, speedPct: -3 }, desc: 'Taglio ampio e controllabile, utile per tenere la distanza.'
  },
  {
    id: 'twinknives', name: 'Twin Knives', rarity: 'Comune', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/common/twinknives.png', behavior: 'twinCombo', damage: 26, cooldown: 0.24, range: 78, cone: 90,
    manaCost: 0, stats: { speedPct: 12, defensePct: -5 }, desc: 'Due coltelli separati che colpiscono in sequenza rapida.'
  },
  {
    id: 'spear', name: 'Spear', rarity: 'Raro', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/rare/spear.png', behavior: 'line', damage: 62, cooldown: 0.76, range: 168, width: 31, knock: 18,
    manaCost: 0, stats: { attackPct: 8, pickupPct: 5 }, desc: 'Affondo lungo e preciso. Premia il controllo della distanza.'
  },
  {
    id: 'revolver', name: 'Revolver', rarity: 'Raro', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/rare/revolver.png', behavior: 'projectile', damage: 45, cooldown: 1.25, bulletSpeed: 540, pierce: 1,
    manaCost: 0, stats: { attackPct: 15, cooldownPct: -4 }, desc: 'Colpo pesante a cadenza lenta. Alta precisione, basso volume di fuoco.'
  },
  {
    id: 'crossbow', name: 'Crossbow', rarity: 'Raro', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/rare/crossbow.png', behavior: 'projectile', damage: 25, cooldown: 1.05, bulletSpeed: 430, pierce: 4,
    manaCost: 0, stats: { attackPct: 8 }, desc: 'Dardi perforanti con ritmo lento. Ottima contro file di nemici.'
  },
  {
    id: 'burstrifle', name: 'Burst Rifle', rarity: 'Raro', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/rare/burstrifle.png', behavior: 'burst', damage: 9, cooldown: 1.08, bulletSpeed: 500, pierce: 1, shots: 3,
    manaCost: 0, stats: { attackPct: 6, bulletSpeedPct: 8 }, desc: 'Raffica a tre colpi con breve pausa tra una scarica e l’altra.'
  },
  {
    id: 'runesword', name: 'Rune Sword', rarity: 'Raro', className: 'Slasher', type: 'Speller',
    path: ASSET + 'weapons/rare/runesword.png', behavior: 'slash', damage: 70, cooldown: 0.92, range: 120, cone: 112,
    manaCost: 8, ability: 'Rune Echo: dopo lo swing parte un secondo taglio runico più largo e più debole.', stats: { maxMana: 20, defensePct: -5 }, desc: 'Spada runica che crea un secondo taglio dopo l’impatto principale.'
  },
  {
    id: 'ghostscythe', name: 'Ghost Scythe', rarity: 'Raro', className: 'Slasher', type: 'Speller',
    path: ASSET + 'weapons/rare/ghostscythe.png', behavior: 'orbitSlash', damage: 34, cooldown: 0.72, range: 98, cone: 115, orbitDamage: 42, orbitCooldown: 3.20, orbitRange: 108,
    manaCost: 5, orbitManaCost: 12, stats: { maxMana: 15, speedPct: 6, maxHp: -8 }, desc: 'Falce spettrale con attacco orbitale periodico per liberare lo spazio vicino.'
  },
  {
    id: 'manabolt', name: 'Mana Bolt', rarity: 'Raro', className: 'Shooter', type: 'Speller',
    path: ASSET + 'weapons/rare/manabolt.png', behavior: 'projectile', damage: 30, cooldown: 0.82, bulletSpeed: 390, pierce: 2,
    manaCost: 7, chainRange: 150, chainMult: 0.55, ability: 'Arc Jump: quando colpisce, rimbalza su un nemico vicino con danno ridotto.', stats: { maxMana: 25 }, desc: 'Proiettile magico che rimbalza tra nemici vicini con danno ridotto.'
  },
  {
    id: 'whiteorb', name: 'White Orb', rarity: 'Raro', className: 'Shooter', type: 'Speller',
    path: ASSET + 'weapons/rare/whiteorb.png', behavior: 'orb', damage: 22, cooldown: 1.45, bulletSpeed: 205, pierce: 8,
    manaCost: 15, pulseRadius: 62, pulseMult: 0.35, ability: 'Orb Pulse: ogni impatto crea una piccola onda che danneggia i nemici vicini.', stats: { maxMana: 20, manaGainPct: 20 }, desc: 'Globo lento multi-hit. Ogni impatto genera un impulso ad area.'
  },
  {
    id: 'warhalberd', name: 'War Halberd', rarity: 'Epico', className: 'Slasher', type: 'Normal',
    path: ASSET + 'weapons/epic/warhalberd.png', behavior: 'slash', damage: 82, cooldown: 1.08, range: 142, cone: 145, knock: 44,
    manaCost: 0, stats: { attackPct: 22, cooldownPct: -10 }, desc: 'Arma pesante con arco ampio e alto danno. Richiede buon posizionamento.'
  },
  {
    id: 'ricochetgun', name: 'Ricochet Gun', rarity: 'Epico', className: 'Shooter', type: 'Normal',
    path: ASSET + 'weapons/epic/ricochetgun.png', behavior: 'ricochet', damage: 28, cooldown: 0.82, bulletSpeed: 500, pierce: 1, ricochetRange: 230, ricochetMult: 0.80,
    manaCost: 0, stats: { attackPct: 10, bulletSpeedPct: 10 }, desc: 'Proiettili a rimbalzo, molto efficaci contro gruppi compatti.'
  },
  {
    id: 'voidkatana', name: 'Void Katana', rarity: 'Epico', className: 'Slasher', type: 'Speller',
    path: ASSET + 'weapons/epic/voidkatana.png', behavior: 'slash', damage: 88, cooldown: 1.04, range: 150, cone: 82, knock: 16,
    manaCost: 14, ability: 'Void Rift: dopo il taglio apre una fenditura lunga che attraversa i nemici.', stats: { maxMana: 35, attackPct: 12, defensePct: -10 }, desc: 'Taglio lungo che consuma mana e attraversa più bersagli.'
  },
  {
    id: 'runelaser', name: 'Rune Laser', rarity: 'Epico', className: 'Shooter', type: 'Speller',
    path: ASSET + 'weapons/epic/runebeam.png', behavior: 'beam', damage: 64, cooldown: 1.18, range: 520, width: 18,
    manaCost: 18, ability: 'Rune Burn: il raggio perfora in linea e poi pulsa sul bersaglio principale.', stats: { maxMana: 40, maxHp: -8 }, desc: 'Raggio preciso verso il nemico più vicino, con forte controllo della linea.'
  },
  {
    id: 'meatsaw', name: 'Meat Saw', rarity: 'Epico', className: 'Slasher', type: 'Killer',
    path: ASSET + 'weapons/epic/meatsaw.png', behavior: 'saw', damage: 7, cooldown: 0.12, range: 94, knock: 8,
    manaCost: 0, frenzyThreshold: 520, frenzyDuration: 4.0, ability: 'Frenzy // Meat Storm: dopo abbastanza danno crea una tempesta di lame attorno al player.', stats: { attackPct: 35, speedPct: -12, defensePct: -5 }, desc: 'Motosega a danno costante da vicino. Ti ferisce del 25% del danno causato.'
  },
  {
    id: 'bloodrifle', name: 'Blood Rifle', rarity: 'Epico', className: 'Shooter', type: 'Killer',
    path: ASSET + 'weapons/epic/bloodrifle.png', behavior: 'projectile', damage: 72, cooldown: 1.15, bulletSpeed: 620, pierce: 2,
    manaCost: 0, frenzyThreshold: 620, frenzyDuration: 4.2, ability: 'Frenzy // Blood Barrage: dopo abbastanza danno scatena una raffica di colpi perforanti.', stats: { attackPct: 40, maxHp: -10 }, desc: 'Colpi precisi e forti. Autodanno 25%. Vita più fragile.'
  }
];

const ENEMY_TYPES = [
  { id: 'crawler', name: 'Crawler', hp: 35, speed: 45, damage: 5, radius: 16, coin: 3, weight: 50, startsAt: 0, desc: 'Nemico base lento e resistente quanto basta per fare pressione.' },
  { id: 'runner', name: 'Runner', hp: 28, speed: 105, damage: 4, radius: 13, coin: 4, weight: 26, startsAt: 12, desc: 'Nemico veloce e fragile, pericoloso se ignorato.' },
  { id: 'brute', name: 'Brute', hp: 150, speed: 32, damage: 13, radius: 25, coin: 12, weight: 12, startsAt: 28, desc: 'Tank lento con molta vita e alto danno da contatto.' },
  { id: 'spitter', name: 'Spitter', hp: 70, speed: 38, damage: 5, radius: 15, coin: 8, weight: 12, startsAt: 40, ranged: true, desc: 'Ranged statico/strano.' }
];

const server = http.createServer((req, res) => {
  try {
    const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
    const cleanPath = urlPath === '/' ? '/index.html' : urlPath;
    const filePath = path.normalize(path.join(ROOT, cleanPath));
    if (!filePath.startsWith(ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }
    fs.readFile(filePath, (err, data) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' });
      res.end(data);
    });
  } catch (err) {
    res.writeHead(500); res.end('Server error');
  }
});


class SimpleWebSocket extends EventEmitter {
  static OPEN = 1;
  constructor(socket) {
    super();
    this.socket = socket;
    this.readyState = SimpleWebSocket.OPEN;
    this.buffer = Buffer.alloc(0);
    socket.on('data', chunk => this.handleData(chunk));
    socket.on('close', () => this.handleClose());
    socket.on('error', () => this.handleClose());
  }

  handleClose() {
    if (this.readyState !== SimpleWebSocket.OPEN) return;
    this.readyState = 3;
    this.emit('close');
  }

  handleData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (this.buffer.length >= 2) {
      const b0 = this.buffer[0];
      const opcode = b0 & 0x0f;
      const b1 = this.buffer[1];
      const masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f;
      let offset = 2;
      if (len === 126) {
        if (this.buffer.length < offset + 2) return;
        len = this.buffer.readUInt16BE(offset);
        offset += 2;
      } else if (len === 127) {
        if (this.buffer.length < offset + 8) return;
        const big = this.buffer.readBigUInt64BE(offset);
        if (big > BigInt(Number.MAX_SAFE_INTEGER)) { this.close(); return; }
        len = Number(big);
        offset += 8;
      }
      let mask;
      if (masked) {
        if (this.buffer.length < offset + 4) return;
        mask = this.buffer.subarray(offset, offset + 4);
        offset += 4;
      }
      if (this.buffer.length < offset + len) return;
      let payload = this.buffer.subarray(offset, offset + len);
      this.buffer = this.buffer.subarray(offset + len);
      if (masked) {
        const unmasked = Buffer.allocUnsafe(payload.length);
        for (let i = 0; i < payload.length; i++) unmasked[i] = payload[i] ^ mask[i % 4];
        payload = unmasked;
      }
      if (opcode === 0x8) { this.close(); return; }
      if (opcode === 0x1) this.emit('message', payload.toString('utf8'));
      if (opcode === 0x9) this.sendFrame(payload, 0xA); // pong
    }
  }

  send(data) {
    if (this.readyState !== SimpleWebSocket.OPEN) return;
    const payload = Buffer.from(String(data), 'utf8');
    this.sendFrame(payload, 0x1);
  }

  sendFrame(payload, opcode) {
    let header;
    if (payload.length < 126) {
      header = Buffer.allocUnsafe(2);
      header[0] = 0x80 | opcode;
      header[1] = payload.length;
    } else if (payload.length < 65536) {
      header = Buffer.allocUnsafe(4);
      header[0] = 0x80 | opcode;
      header[1] = 126;
      header.writeUInt16BE(payload.length, 2);
    } else {
      header = Buffer.allocUnsafe(10);
      header[0] = 0x80 | opcode;
      header[1] = 127;
      header.writeBigUInt64BE(BigInt(payload.length), 2);
    }
    this.socket.write(Buffer.concat([header, payload]));
  }

  close() {
    if (this.readyState !== SimpleWebSocket.OPEN) return;
    this.readyState = 3;
    try { this.socket.end(); } catch (_) {}
    this.emit('close');
  }
}

function handleUpgrade(req, socket) {
  const key = req.headers['sec-websocket-key'];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash('sha1')
    .update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
    .digest('base64');
  socket.write([
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    'Sec-WebSocket-Accept: ' + accept,
    '',
    ''
  ].join('\r\n'));
  handleConnection(new SimpleWebSocket(socket));
}

let nextClientId = 1;
let nextEnemyId = 1;
let nextProjectileId = 1;
let hostId = null;
const clients = new Map();

const room = {
  mode: 'lobby',
  t: 0,
  winTime: 0,
  spawnTimer: 0,
  spawnInterval: 1.1,
  runCoins: 0,
  kills: 0,
  enemies: [],
  projectiles: [],
  enemyBullets: [],
  effects: [],
  delayed: []
};

function getWeapon(id) { return WEAPONS.find(w => w.id === id) || WEAPONS.find(w => w.id === 'pistol'); }
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function normAngle(a) { return Math.atan2(Math.sin(a), Math.cos(a)); }
function cleanName(name) { return String(name || 'Player').replace(/[^a-zA-Z0-9_ \-]/g, '').slice(0, 14) || 'Player'; }
function cleanHat(id) { const key = String(id || 'none').trim().toLowerCase(); return HAT_IDS.has(key) ? key : 'none'; }
function send(ws, msg) { if (ws.readyState === SimpleWebSocket.OPEN) ws.send(JSON.stringify(msg)); }
function broadcast(msg) { for (const c of clients.values()) send(c.ws, msg); }

function buildStats(primary) {
  const s = primary.stats || {};
  const maxHp = Math.max(30, 100 + (s.maxHp || 0));
  const maxMana = Math.max(0, 60 + (s.maxMana || 0));
  return {
    maxHp,
    hp: maxHp,
    maxMana,
    mana: maxMana,
    manaKillGain: 14 * (1 + (s.manaGainPct || 0) / 100),
    hpKillGain: 6,
    speed: 150 * (1 + (s.speedPct || 0) / 100),
    attackMult: 1 + (s.attackPct || 0) / 100,
    defenseMult: clamp(1 - (s.defensePct || 0) / 100, 0.25, 1.5),
    cooldownMult: clamp(1 - (s.cooldownPct || 0) / 100, 0.25, 2),
    bulletSpeedMult: 1 + (s.bulletSpeedPct || 0) / 100,
    pickupRange: 42 * (1 + (s.pickupPct || 0) / 100)
  };
}

function makeRuntimeWeapon(w) {
  return { ...w, timer: 0, swingTimer: 0, swingMax: 0, swingAngle: 0, swingDir: 1, twinSide: 1, activeTwinSide: 1, orbitTimer: 0, frenzyTimer: 0, frenzyCharge: 0, frenzyThreshold: w.frenzyThreshold || 600 };
}

function makePlayer(client, index) {
  const primary = getWeapon(client.primary);
  const secondary = getWeapon(client.secondary);
  const stats = buildStats(primary);
  const spawnPoints = [
    { x: W / 2 - 38, y: H / 2 },
    { x: W / 2 + 38, y: H / 2 },
    { x: W / 2, y: H / 2 - 38 },
    { x: W / 2, y: H / 2 + 38 }
  ];
  return {
    id: client.id,
    name: client.name,
    index,
    x: spawnPoints[index]?.x || W / 2,
    y: spawnPoints[index]?.y || H / 2,
    vx: 0,
    vy: 0,
    r: 12,
    lastAngle: -Math.PI / 2,
    aimAngle: -Math.PI / 2,
    displayAngle: -Math.PI / 2,
    invuln: 0,
    hurtFlash: 0,
    dead: false,
    activeWeaponIndex: 0,
    weapons: [makeRuntimeWeapon(primary), makeRuntimeWeapon(secondary)],
    primary: primary.id,
    secondary: secondary.id,
    hat: cleanHat(client.hat),
    ...stats
  };
}

function resetRoomToLobby() {
  room.mode = 'lobby';
  room.t = 0;
  room.runCoins = 0;
  room.kills = 0;
  room.spawnTimer = 0;
  room.spawnInterval = 1.1;
  room.enemies = [];
  room.projectiles = [];
  room.enemyBullets = [];
  room.effects = [];
  room.delayed = [];
  for (const c of clients.values()) { c.ready = false; c.player = null; c.input = defaultInput(); }
  broadcastLobby();
}

function defaultInput() { return { up: false, down: false, left: false, right: false, active: 0 }; }

function startGame() {
  const list = [...clients.values()].filter(c => c.ready).slice(0, MAX_PLAYERS);
  if (list.length < 1) return false;
  room.mode = 'playing';
  room.t = 0;
  room.runCoins = 0;
  room.kills = 0;
  room.spawnTimer = 0.3;
  room.enemies = [];
  room.projectiles = [];
  room.enemyBullets = [];
  room.effects = [];
  room.delayed = [];
  list.forEach((c, idx) => { c.player = makePlayer(c, idx); c.input = defaultInput(); });
  for (const c of clients.values()) {
    if (!list.includes(c)) c.player = null;
  }
  broadcast({ type: 'gameStart', state: snapshot() });
  return true;
}

function lobbyData() {
  return {
    mode: room.mode,
    hostId,
    players: [...clients.values()].map(c => ({
      id: c.id,
      name: c.name,
      ready: c.ready,
      host: c.id === hostId,
      primary: c.primary,
      secondary: c.secondary,
      hat: c.hat || 'none'
    }))
  };
}

function broadcastLobby() { broadcast({ type: 'lobby', lobby: lobbyData() }); }

function activePlayers() { return [...clients.values()].map(c => c.player).filter(p => p && !p.dead); }
function allRunPlayers() { return [...clients.values()].map(c => c.player).filter(Boolean); }

function nearestEnemyToPlayer(p, maxDist = Infinity) {
  let best = null, bestD = maxDist;
  for (const e of room.enemies) {
    if (e.dead) continue;
    const d = Math.hypot(e.x - p.x, e.y - p.y);
    if (d < bestD) { best = e; bestD = d; }
  }
  return best;
}

function nearestPlayerToEnemy(e) {
  let best = null, bestD = Infinity;
  for (const p of activePlayers()) {
    const d = Math.hypot(p.x - e.x, p.y - e.y);
    if (d < bestD) { best = p; bestD = d; }
  }
  return best;
}

function update(dt) {
  if (room.mode !== 'playing') return;
  room.t += dt;
  updatePlayers(dt);
  updateWeapons(dt);
  updateProjectiles(dt);
  updateEnemies(dt);
  updateEnemyBullets(dt);
  updateEffects(dt);
  updateDelayed(dt);
  spawnEnemies(dt);
  if (allRunPlayers().length > 0 && activePlayers().length === 0) endGame(false, 'Tutti i player sono morti. LAN pain.');
  // No LAN victory timer in FULLAN-fix: LAN runs end when the team dies or quits.
}

function updatePlayers(dt) {
  for (const c of clients.values()) {
    const p = c.player;
    if (!p || p.dead) continue;
    const input = c.input || defaultInput();
    let dx = 0, dy = 0;
    if (input.up) dy -= 1;
    if (input.down) dy += 1;
    if (input.left) dx -= 1;
    if (input.right) dx += 1;
    const len = Math.hypot(dx, dy) || 1;
    if (dx || dy) { dx /= len; dy /= len; p.lastAngle = Math.atan2(dy, dx); }
    const targetVx = dx * p.speed;
    const targetVy = dy * p.speed;
    const accel = (dx || dy) ? 15 : 18;
    p.vx += (targetVx - p.vx) * Math.min(1, accel * dt);
    p.vy += (targetVy - p.vy) * Math.min(1, accel * dt);
    p.x = clamp(p.x + p.vx * dt, 18, W - 18);
    p.y = clamp(p.y + p.vy * dt, 18, H - 18);
    const target = nearestEnemyToPlayer(p, 900);
    p.aimAngle = target ? Math.atan2(target.y - p.y, target.x - p.x) : p.lastAngle;
    p.displayAngle += normAngle(p.aimAngle - p.displayAngle) * Math.min(1, 12 * dt);
    p.invuln = Math.max(0, p.invuln - dt);
    p.hurtFlash = Math.max(0, p.hurtFlash - dt);
    p.activeWeaponIndex = input.active === 1 ? 1 : 0;
  }
}

function updateWeapons(dt) {
  for (const p of activePlayers()) {
    const active = p.weapons[p.activeWeaponIndex || 0];
    for (const w of p.weapons) {
      w.swingTimer = Math.max(0, (w.swingTimer || 0) - dt);
      w.orbitTimer = Math.max(0, (w.orbitTimer || 0) - dt);
      w.frenzyTimer = Math.max(0, (w.frenzyTimer || 0) - dt);
      if (w !== active) w.timer = Math.max(0, w.timer - dt * 0.55);
    }
    if (!active) continue;
    active.timer -= dt;
    if (active.timer <= 0) {
      if (!hasTargetForWeapon(p, active)) { active.timer = 0.06; continue; }
      if (active.behavior === 'orbitSlash') {
        fireGhostScytheSmart(p, active);
        continue;
      }
      if (active.manaCost && p.mana < active.manaCost) { active.timer = 0.12; continue; }
      if (active.manaCost) p.mana -= active.manaCost;
      fireWeapon(p, active);
      active.timer = weaponCooldown(p, active);
    }
  }
}

function hasTargetForWeapon(p, w) {
  if (!w || !room.enemies.length) return false;
  if (w.className === 'Slasher') return !!nearestEnemyToPlayer(p, (w.range || 75) + 26);
  return !!nearestEnemyToPlayer(p, 900);
}

function weaponCooldown(p, w) {
  const frenzyMult = (w && w.frenzyTimer > 0) ? 0.55 : 1;
  return Math.max(0.08, (w.cooldown || 0.70) * p.cooldownMult * frenzyMult);
}
function scaledDamage(p, w) {
  const frenzyMult = (w && w.frenzyTimer > 0) ? 1.45 : 1;
  return Math.max(1, Math.round(w.damage * p.attackMult * frenzyMult));
}
function runtimeWeaponForPlayer(p, id) {
  return p?.weapons?.find(w => w.id === id) || getWeapon(id);
}

function fireGhostScytheSmart(p, w) {
  const target = nearestEnemyToPlayer(p, (w.orbitRange || w.range || 108) + 30);
  if (!target) { w.timer = 0.08; return; }
  w.orbitTimer = Math.max(0, w.orbitTimer || 0);
  const angle = Math.atan2(target.y - p.y, target.x - p.x);

  if (w.orbitTimer <= 0 && p.mana >= (w.orbitManaCost || 12)) {
    p.mana -= (w.orbitManaCost || 12);
    w.swingDir = (w.swingDir || 1) * -1;
    w.swingAngle = angle;
    w.swingTimer = 0.78;
    w.swingMax = 0.78;
    fireOrbit(p, w, angle);
    w.orbitTimer = (w.orbitCooldown || 3.2) * p.cooldownMult;
    w.timer = weaponCooldown(p, w);
    return;
  }

  if (w.manaCost && p.mana < w.manaCost) { w.timer = 0.12; return; }
  if (w.manaCost) p.mana -= w.manaCost;
  w.swingDir = (w.swingDir || 1) * -1;
  w.swingAngle = angle;
  w.swingTimer = 0.24;
  w.swingMax = 0.24;
  fireSlash(p, w, angle);
  w.timer = weaponCooldown(p, w);
}

function fireWeapon(p, w) {
  const target = nearestEnemyToPlayer(p, 700);
  const angle = target ? Math.atan2(target.y - p.y, target.x - p.x) : p.displayAngle;
  w.swingDir = (w.swingDir || 1) * -1;
  w.swingAngle = angle;
  if (w.className === 'Slasher') { w.swingTimer = w.behavior === 'orbit' ? 0.78 : 0.22; w.swingMax = w.swingTimer; }
  if (w.behavior === 'projectile') fireProjectile(p, w, angle);
  else if (w.behavior === 'burst') {
    fireProjectile(p, w, angle - 0.07);
    schedule(0.08, () => fireProjectile(p, w, angle));
    schedule(0.16, () => fireProjectile(p, w, angle + 0.07));
  } else if (w.behavior === 'orb') fireOrb(p, w, angle);
  else if (w.behavior === 'ricochet') fireProjectile(p, w, angle);
  else if (w.behavior === 'beam') fireBeam(p, w, angle);
  else if (w.behavior === 'saw') fireSaw(p, w, angle);
  else if (w.behavior === 'slash') fireSlash(p, w, angle);
  else if (w.behavior === 'twinCombo') fireTwin(p, w, angle);
  else if (w.behavior === 'orbit') fireOrbit(p, w, angle);
  else if (w.behavior === 'orbitSlash') fireSlash(p, w, angle);
  else if (w.behavior === 'line') fireLine(p, w, angle);
}

function fireProjectile(p, w, angle) {
  const speed = (w.bulletSpeed || 400) * p.bulletSpeedMult;
  room.projectiles.push({ id: nextProjectileId++, owner: p.id, x: p.x + Math.cos(angle) * 18, y: p.y + Math.sin(angle) * 18, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, r: w.type === 'Speller' ? 7 : 5, damage: scaledDamage(p, w), pierce: w.pierce || 1, life: 2.4, weaponId: w.id, angle, hit: new Set() });
}
function fireOrb(p, w, angle) { const speed = (w.bulletSpeed || 220) * p.bulletSpeedMult; room.projectiles.push({ id: nextProjectileId++, owner: p.id, x: p.x + Math.cos(angle) * 20, y: p.y + Math.sin(angle) * 20, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, r: 20, damage: scaledDamage(p, w), pierce: w.pierce || 8, life: 3.2, weaponId: w.id, angle, hit: new Set(), orb: true }); }

function fireSlash(p, w, angle) {
  const range = w.range || 75;
  const cone = (w.cone || 90) * Math.PI / 180;
  for (const e of room.enemies) {
    if (e.dead) continue;
    const ex = e.x - p.x, ey = e.y - p.y;
    const d = Math.hypot(ex, ey);
    if (d <= range + e.r) {
      const a = Math.atan2(ey, ex);
      if (Math.abs(normAngle(a - angle)) <= cone / 2) damageEnemy(e, scaledDamage(p, w), p.x, p.y, w.knock || 18, p, w);
    }
  }
  addFx({ type: w._echo ? 'runeEcho' : 'slash', owner: p.id, x: p.x, y: p.y, angle, range, life: w._echo ? 0.30 : 0.24, maxLife: w._echo ? 0.30 : 0.24, weaponId: w.id });
  if (w.id === 'runesword' && !w._echo) schedule(0.15, () => fireRuneEcho(p, w, angle));
  if (w.id === 'voidkatana' && !w._echo) schedule(0.11, () => fireVoidRift(p, w, angle));
}

function fireRuneEcho(p, w, angle) {
  const echo = { ...w, _echo: true, damage: Math.max(1, Math.round(w.damage * 0.45)), range: (w.range || 120) + 28, cone: (w.cone || 112) + 18, knock: 8 };
  fireSlash(p, echo, angle);
}

function fireTwin(p, w, angle) {
  w.twinSide = w.twinSide === 1 ? -1 : 1;
  w.activeTwinSide = w.twinSide;
  const doHit = (side) => {
    const hitAngle = p.displayAngle + side * 0.34;
    const range = w.range || 78;
    const cone = (w.cone || 90) * Math.PI / 180;
    for (const e of room.enemies) {
      if (e.dead) continue;
      const ex = e.x - p.x, ey = e.y - p.y;
      const d = Math.hypot(ex, ey);
      if (d <= range + e.r) {
        const a = Math.atan2(ey, ex);
        if (Math.abs(normAngle(a - hitAngle)) <= cone / 2) damageEnemy(e, scaledDamage(p, w), p.x, p.y, 11, p, w);
      }
    }
    addFx({ type: 'twin', owner: p.id, x: p.x, y: p.y, angle: hitAngle, side, range, weaponId: w.id, life: 0.16, maxLife: 0.16 });
  };
  doHit(w.twinSide);
  schedule(0.12, () => doHit(-w.twinSide));
}

function fireOrbit(p, w, angle) { addFx({ type: 'orbitScythe', owner: p.id, weaponId: w.id, startAngle: angle, range: w.orbitRange || w.range || 108, damage: Math.max(1, Math.round((w.orbitDamage || w.damage) * p.attackMult)), hit: new Set(), life: 0.78, maxLife: 0.78 }); }
function fireLine(p, w, angle) {
  const length = w.range || 140;
  const width = w.width || 24;
  const ex2 = p.x + Math.cos(angle) * length;
  const ey2 = p.y + Math.sin(angle) * length;
  for (const e of room.enemies) if (!e.dead && pointLineDistance(e.x, e.y, p.x, p.y, ex2, ey2) <= width + e.r) damageEnemy(e, scaledDamage(p, w), p.x, p.y, w.knock || 16, p, w);
  addFx({ type: 'line', owner: p.id, x: p.x, y: p.y, angle, range: length, width, life: 0.24, maxLife: 0.24, weaponId: w.id });
}


function fireBeam(p, w, angle) {
  const length = w.range || 520;
  const width = w.width || 16;
  const ex = p.x + Math.cos(angle) * length;
  const ey = p.y + Math.sin(angle) * length;
  let primaryHit = null;
  let bestDist = Infinity;
  for (const e of room.enemies) {
    if (e.dead) continue;
    const lineDist = pointLineDistance(e.x, e.y, p.x, p.y, ex, ey);
    if (lineDist <= width + e.r) {
      const along = Math.hypot(e.x - p.x, e.y - p.y);
      if (along < bestDist) { bestDist = along; primaryHit = e; }
      damageEnemy(e, scaledDamage(p, w), p.x, p.y, 6, p, w);
    }
  }
  if (primaryHit) schedule(0.08, () => runeLaserPulse(p, primaryHit.x, primaryHit.y, Math.round(scaledDamage(p, w) * 0.35), w));
  addFx({ type: 'beam', owner: p.id, x: p.x, y: p.y, angle, range: length, width, life: 0.18, maxLife: 0.18, weaponId: w.id });
}

function runeLaserPulse(p, x, y, dmg, w) {
  const radius = 54;
  for (const e of room.enemies) if (!e.dead && Math.hypot(e.x - x, e.y - y) <= radius + e.r) damageEnemy(e, dmg, x, y, 6, p, w);
  addFx({ type: 'pulse', x, y, radius, life: 0.20, maxLife: 0.20, owner: p.id });
}

function fireSaw(p, w, angle) {
  const radius = w.range || 88;
  for (const e of room.enemies) {
    if (!e.dead && Math.hypot(e.x - p.x, e.y - p.y) <= radius + e.r) damageEnemy(e, scaledDamage(p, w), p.x, p.y, w.knock || 30, p, w);
  }
  addFx({ type: 'saw', owner: p.id, x: p.x, y: p.y, radius, angle, life: 0.24, maxLife: 0.24, weaponId: w.id });
}

function fireVoidRift(p, w, angle) {
  const length = (w.range || 150) + 70;
  const width = 24;
  const ex = p.x + Math.cos(angle) * length;
  const ey = p.y + Math.sin(angle) * length;
  const dmg = Math.max(1, Math.round(scaledDamage(p, w) * 0.55));
  for (const e of room.enemies) if (!e.dead && pointLineDistance(e.x, e.y, p.x, p.y, ex, ey) <= width + e.r) damageEnemy(e, dmg, p.x, p.y, 10, p, w);
  addFx({ type: 'voidRift', owner: p.id, x: p.x, y: p.y, angle, range: length, width, life: 0.30, maxLife: 0.30, weaponId: w.id });
}

function ricochetBounce(sourceEnemy, baseDamage, hitSet, killer = null, sourceWeapon = null) {
  let best = null, bestD = sourceWeapon?.ricochetRange || 230;
  for (const e of room.enemies) {
    if (e.dead || hitSet.has(e.uid) || e === sourceEnemy) continue;
    const d = Math.hypot(e.x - sourceEnemy.x, e.y - sourceEnemy.y);
    if (d < bestD) { best = e; bestD = d; }
  }
  if (!best) return;
  hitSet.add(best.uid);
  const dmg = Math.max(1, Math.round(baseDamage * (sourceWeapon?.ricochetMult || 0.8)));
  damageEnemy(best, dmg, sourceEnemy.x, sourceEnemy.y, 9, killer, sourceWeapon);
  addFx({ type: 'ricochet', x1: sourceEnemy.x, y1: sourceEnemy.y, x2: best.x, y2: best.y, life: 0.16, maxLife: 0.16 });
}

function pointLineDistance(px, py, x1, y1, x2, y2) { const dx = x2 - x1, dy = y2 - y1; const l2 = dx * dx + dy * dy; if (!l2) return Math.hypot(px - x1, py - y1); let t = ((px - x1) * dx + (py - y1) * dy) / l2; t = clamp(t, 0, 1); const x = x1 + t * dx, y = y1 + t * dy; return Math.hypot(px - x, py - y); }
function schedule(delay, fn) { room.delayed.push({ delay, fn }); }
function updateDelayed(dt) { for (let i = room.delayed.length - 1; i >= 0; i--) { const a = room.delayed[i]; a.delay -= dt; if (a.delay <= 0) { room.delayed.splice(i, 1); try { a.fn(); } catch (_) {} } } }
function addFx(fx) { room.effects.push({ ...fx, fxId: Math.random().toString(36).slice(2) }); }

function updateProjectiles(dt) {
  for (let i = room.projectiles.length - 1; i >= 0; i--) {
    const p = room.projectiles[i];
    p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
    for (const e of room.enemies) {
      if (e.dead || p.hit.has(e.uid)) continue;
      if (Math.hypot(e.x - p.x, e.y - p.y) <= e.r + p.r) {
        const ownerPlayer = allRunPlayers().find(pl => pl.id === p.owner) || null;
        const sourceWeapon = runtimeWeaponForPlayer(ownerPlayer, p.weaponId);
        damageEnemy(e, p.damage, p.x - p.vx * 0.03, p.y - p.vy * 0.03, p.orb ? 8 : 5, ownerPlayer, sourceWeapon);
        p.hit.add(e.uid);
        if (p.weaponId === 'manabolt') manaBoltChain(e, p.damage, p.hit, ownerPlayer, sourceWeapon);
        if (p.weaponId === 'whiteorb') whiteOrbPulse(e.x, e.y, p.damage, p.hit, ownerPlayer, sourceWeapon);
        if (p.weaponId === 'ricochetgun') ricochetBounce(e, p.damage, p.hit, ownerPlayer, sourceWeapon);
        p.pierce--;
        if (p.pierce <= 0) break;
      }
    }
    if (p.life <= 0 || p.pierce <= 0 || p.x < -60 || p.x > W + 60 || p.y < -60 || p.y > H + 60) room.projectiles.splice(i, 1);
  }
}


function manaBoltChain(sourceEnemy, baseDamage, hitSet, killer = null, sourceWeapon = null) {
  let best = null, bestD = 150;
  for (const e of room.enemies) {
    if (e.dead || hitSet.has(e.uid) || e === sourceEnemy) continue;
    const d = Math.hypot(e.x - sourceEnemy.x, e.y - sourceEnemy.y);
    if (d < bestD) { best = e; bestD = d; }
  }
  if (!best) return;
  hitSet.add(best.uid);
  const dmg = Math.max(1, Math.round(baseDamage * 0.55));
  damageEnemy(best, dmg, sourceEnemy.x, sourceEnemy.y, 10, killer, sourceWeapon);
  addFx({ type: 'zap', x1: sourceEnemy.x, y1: sourceEnemy.y, x2: best.x, y2: best.y, life: 0.16, maxLife: 0.16 });
}

function whiteOrbPulse(x, y, baseDamage, hitSet, killer = null, sourceWeapon = null) {
  const radius = 62;
  const dmg = Math.max(1, Math.round(baseDamage * 0.35));
  for (const e of room.enemies) {
    if (e.dead || hitSet.has(e.uid)) continue;
    if (Math.hypot(e.x - x, e.y - y) <= radius + e.r) {
      hitSet.add(e.uid);
      damageEnemy(e, dmg, x, y, 8, killer, sourceWeapon);
    }
  }
  addFx({ type: 'pulse', x, y, radius, life: 0.22, maxLife: 0.22 });
}


function handleKillRewards(killer, e) {
  if (!killer || killer.dead) return;

  // LANB 0.5B mana rule: no passive mana regeneration.
  // Mana comes back from kills, with 75% chance, to the player who caused the kill.
  if (killer.maxMana > 0 && Math.random() < 0.75) {
    const amount = Math.max(8, Math.round(killer.manaKillGain || 14));
    const before = killer.mana;
    killer.mana = clamp(killer.mana + amount, 0, killer.maxMana);
    if (killer.mana > before) addFx({ type: 'manaReward', x: e.x, y: e.y - 10, life: 0.35, maxLife: 0.35, owner: killer.id });
  }

  // Kill sustain: 25% chance to recover a little HP.
  if (Math.random() < 0.25) {
    const amount = Math.max(4, Math.round(killer.hpKillGain || 6));
    const before = killer.hp;
    killer.hp = clamp(killer.hp + amount, 0, killer.maxHp);
    if (killer.hp > before) addFx({ type: 'healReward', x: e.x, y: e.y + 10, life: 0.35, maxLife: 0.35, owner: killer.id });
  }
}

function damageEnemy(e, amount, sx, sy, knock = 0, killer = null, sourceWeapon = null) {
  if (!e || e.dead) return;
  e.hp -= amount; e.flash = 0.10;
  handleWeaponDamage(killer, sourceWeapon, amount);
  if (knock > 0) { const dx = e.x - sx, dy = e.y - sy; const d = Math.hypot(dx, dy) || 1; e.x += (dx / d) * knock; e.y += (dy / d) * knock; }
  addFx({ type: 'hit', x: e.x, y: e.y, life: 0.12, maxLife: 0.12 });
  if (e.hp <= 0) { e.dead = true; room.kills++; room.runCoins += e.coin; handleKillRewards(killer, e); addFx({ type: 'coinpop', x: e.x, y: e.y, value: e.coin, life: 0.45, maxLife: 0.45 }); }
}

function handleWeaponDamage(player, w, amount) {
  if (!player || !w || w.type !== 'Killer' || player.dead) return;
  const selfDamage = Math.max(1, Math.round(amount * 0.25));
  player.hp -= selfDamage;
  player.hurtFlash = 0.14;
  addFx({ type: 'playerHit', x: player.x, y: player.y, life: 0.12, maxLife: 0.12, owner: player.id });
  if (player.hp <= 0) { player.hp = 0; player.dead = true; addFx({ type: 'playerDead', x: player.x, y: player.y, life: 0.8, maxLife: 0.8 }); return; }
  if ((w.frenzyTimer || 0) > 0) return;
  w.frenzyCharge = (w.frenzyCharge || 0) + amount;
  if (w.frenzyCharge >= (w.frenzyThreshold || 600)) startKillerFrenzy(player, w);
}

function startKillerFrenzy(player, w) {
  if (!player || !w || w.type !== 'Killer') return;
  w.frenzyCharge = 0;
  w.frenzyTimer = w.frenzyDuration || 4.0;
  addFx({ type: 'frenzyStart', owner: player.id, x: player.x, y: player.y, radius: 72, life: 0.40, maxLife: 0.40, weaponId: w.id });
  if (w.id === 'meatsaw') {
    addFx({ type: 'frenzySaw', owner: player.id, weaponId: w.id, range: 112, damage: Math.max(1, Math.round((w.damage || 7) * player.attackMult * 2.2)), hitCooldown: {}, life: 3.0, maxLife: 3.0 });
  }
  if (w.id === 'bloodrifle') {
    for (let i = 0; i < 9; i++) schedule(i * 0.07, () => {
      if (room.mode !== 'playing' || player.dead) return;
      const target = nearestEnemyToPlayer(player, 850);
      const angle = target ? Math.atan2(target.y - player.y, target.x - player.x) : player.displayAngle;
      const shot = { ...w, damage: Math.max(1, Math.round(w.damage * 0.70)), pierce: 3, bulletSpeed: 720 };
      fireProjectile(player, shot, angle + (Math.random() - 0.5) * 0.18);
    });
  }
}

function updateEnemies(dt) {
  const players = activePlayers();
  for (let i = room.enemies.length - 1; i >= 0; i--) {
    const e = room.enemies[i];
    if (e.dead) { room.enemies.splice(i, 1); continue; }
    e.flash = Math.max(0, (e.flash || 0) - dt); e.hitCd = Math.max(0, (e.hitCd || 0) - dt);
    if (!players.length) continue;
    const target = nearestPlayerToEnemy(e);
    if (!target) continue;
    const dx = target.x - e.x, dy = target.y - e.y; const d = Math.hypot(dx, dy) || 1;
    let moveX = dx / d, moveY = dy / d;
    if (e.ranged) {
      e.shootCd -= dt;
      if (d < 185) { moveX *= -1; moveY *= -1; }
      if (d >= 185 && d <= 230) { moveX = 0; moveY = 0; }
      if (e.shootCd <= 0) { enemyShoot(e, Math.atan2(dy, dx)); e.shootCd = 2.2; }
    }
    e.x += moveX * e.speed * dt; e.y += moveY * e.speed * dt;
    if (d <= e.r + target.r && e.hitCd <= 0) { damagePlayer(target, Math.max(1, e.damage * target.defenseMult)); e.hitCd = 0.75; }
  }
}

function damagePlayer(p, amount) { if (!p || p.dead || p.invuln > 0) return; p.hp -= amount; p.invuln = 0.45; p.hurtFlash = 0.18; addFx({ type: 'playerHit', x: p.x, y: p.y, life: 0.18, maxLife: 0.18 }); if (p.hp <= 0) { p.hp = 0; p.dead = true; addFx({ type: 'playerDead', x: p.x, y: p.y, life: 0.8, maxLife: 0.8 }); } }
function enemyShoot(e, angle) { room.enemyBullets.push({ x: e.x + Math.cos(angle) * 14, y: e.y + Math.sin(angle) * 14, vx: Math.cos(angle) * 160, vy: Math.sin(angle) * 160, r: 5, damage: e.damage, life: 4 }); }
function updateEnemyBullets(dt) { for (let i = room.enemyBullets.length - 1; i >= 0; i--) { const b = room.enemyBullets[i]; b.life -= dt; b.x += b.vx * dt; b.y += b.vy * dt; for (const p of activePlayers()) { if (Math.hypot(b.x - p.x, b.y - p.y) <= b.r + p.r) { damagePlayer(p, Math.max(1, b.damage * p.defenseMult)); room.enemyBullets.splice(i, 1); break; } } if (i < room.enemyBullets.length && (b.life <= 0 || b.x < -30 || b.y < -30 || b.x > W + 30 || b.y > H + 30)) room.enemyBullets.splice(i, 1); } }
function updateEffects(dt) { for (let i = room.effects.length - 1; i >= 0; i--) { const fx = room.effects[i]; if (fx.type === 'orbitScythe') updateOrbit(fx); if (fx.type === 'frenzySaw') updateFrenzySaw(fx, dt); fx.life -= dt; if (fx.life <= 0) room.effects.splice(i, 1); } }
function updateOrbit(fx) { const p = allRunPlayers().find(p => p.id === fx.owner && !p.dead); if (!p) return; const progress = 1 - fx.life / fx.maxLife; const angle = fx.startAngle + progress * Math.PI * 2; const sx = p.x + Math.cos(angle) * fx.range; const sy = p.y + Math.sin(angle) * fx.range; for (const e of room.enemies) { if (e.dead || fx.hit.has(e.uid)) continue; if (Math.hypot(e.x - sx, e.y - sy) <= e.r + 34) { fx.hit.add(e.uid); damageEnemy(e, fx.damage, p.x, p.y, 20, p, runtimeWeaponForPlayer(p, fx.weaponId)); } } }
function updateFrenzySaw(fx, dt) { const p = allRunPlayers().find(p => p.id === fx.owner && !p.dead); if (!p) return; for (const id of Object.keys(fx.hitCooldown || {})) { fx.hitCooldown[id] -= dt; if (fx.hitCooldown[id] <= 0) delete fx.hitCooldown[id]; } for (const e of room.enemies) { if (e.dead || fx.hitCooldown[e.uid]) continue; if (Math.hypot(e.x - p.x, e.y - p.y) <= (fx.range || 110) + e.r) { fx.hitCooldown[e.uid] = 0.28; damageEnemy(e, fx.damage, p.x, p.y, 24, p, runtimeWeaponForPlayer(p, fx.weaponId)); } } }

function spawnEnemies(dt) {
  room.spawnTimer -= dt;
  const playerCount = Math.max(1, allRunPlayers().length);
  const pressure = Math.floor(room.t / 25);
  const enemyCap = playerCount >= 2 ? 72 + playerCount * 18 : 80;
  if (room.enemies.length >= enemyCap) return;

  // LAN-fix: fewer enemies, stronger enemies. Less lag, more danger.
  room.spawnInterval = clamp(1.30 - room.t * 0.0022 - (playerCount - 1) * 0.04, 0.42, 1.30);
  if (room.spawnTimer <= 0) {
    room.spawnTimer = room.spawnInterval;
    let count = 1 + (Math.random() < Math.min(0.55, room.t / 170) ? 1 : 0);
    if (playerCount >= 3 && Math.random() < 0.35) count++;
    if (pressure >= 4 && Math.random() < 0.18) count++;
    count = Math.min(count, enemyCap - room.enemies.length);
    for (let i = 0; i < count; i++) spawnOneEnemy(playerCount);
  }
}

function weightedPick(items, weightFn) { const total = items.reduce((sum, item) => sum + weightFn(item), 0); let roll = Math.random() * total; for (const item of items) { roll -= weightFn(item); if (roll <= 0) return item; } return items[items.length - 1]; }
function spawnOneEnemy(playerCount) {
  const available = ENEMY_TYPES.filter(e => room.t >= e.startsAt);
  const type = weightedPick(available, e => e.weight);
  const side = Math.floor(Math.random() * 4);
  let x, y;
  if (side === 0) { x = Math.random() * W; y = -35; } else if (side === 1) { x = W + 35; y = Math.random() * H; } else if (side === 2) { x = Math.random() * W; y = H + 35; } else { x = -35; y = Math.random() * H; }
  const hpMult = playerCount >= 2 ? 1 + (playerCount - 1) * 0.65 : 1;
  const dmgMult = playerCount >= 2 ? 1 + (playerCount - 1) * 0.25 : 1;
  const speedMult = playerCount >= 2 ? 1 + (playerCount - 1) * 0.06 : 1;
  const scaledHp = Math.round((type.hp + Math.floor(room.t / 45) * 4) * hpMult);
  const scaledDamage = Math.max(1, Math.round(type.damage * dmgMult));
  const scaledSpeed = Math.round(type.speed * speedMult);
  room.enemies.push({ ...type, uid: nextEnemyId++, x, y, r: type.radius, hp: scaledHp, maxHp: scaledHp, damage: scaledDamage, speed: scaledSpeed, shootCd: 1.2 + Math.random() * 1.4, hitCd: 0, flash: 0, dead: false });
}

function endGame(victory, text) {
  if (room.mode !== 'playing') return;
  room.mode = 'ended';
  const payload = { type: 'gameOver', victory: false, text, kills: room.kills, coins: room.runCoins };
  broadcast(payload);
  setTimeout(resetRoomToLobby, 1200);
}

function publicPlayer(p) {
  return { id: p.id, name: p.name, index: p.index, x: p.x, y: p.y, r: p.r, hp: p.hp, maxHp: p.maxHp, mana: p.mana, maxMana: p.maxMana, dead: p.dead, activeWeaponIndex: p.activeWeaponIndex, primary: p.primary, secondary: p.secondary, hat: p.hat || 'none', displayAngle: p.displayAngle, lastAngle: p.lastAngle, hurtFlash: p.hurtFlash, weapons: p.weapons.map(w => ({ id: w.id, swingTimer: w.swingTimer || 0, swingMax: w.swingMax || 0, swingAngle: w.swingAngle || p.displayAngle, swingDir: w.swingDir || 1, activeTwinSide: w.activeTwinSide || 1, frenzyTimer: w.frenzyTimer || 0, frenzyCharge: w.frenzyCharge || 0, frenzyThreshold: w.frenzyThreshold || 0 })) };
}
function publicEnemy(e) { return { uid: e.uid, id: e.id, x: e.x, y: e.y, r: e.r, hp: e.hp, maxHp: e.maxHp, flash: e.flash || 0, ranged: !!e.ranged }; }
function publicProjectile(p) { return { id: p.id, owner: p.owner, x: p.x, y: p.y, r: p.r, weaponId: p.weaponId, angle: p.angle, orb: !!p.orb }; }
function publicFx(fx) { const copy = { ...fx }; delete copy.hit; return copy; }
function snapshot() { return { mode: room.mode, t: room.t, winTime: room.winTime, kills: room.kills, runCoins: room.runCoins, players: allRunPlayers().map(publicPlayer), enemies: room.enemies.map(publicEnemy), projectiles: room.projectiles.map(publicProjectile), enemyBullets: room.enemyBullets.map(b => ({ x: b.x, y: b.y, r: b.r })), effects: room.effects.map(publicFx) }; }
let lastSnapshot = 0;
setInterval(() => update(TICK / 1000), TICK);
setInterval(() => { if (room.mode === 'playing') broadcast({ type: 'state', state: snapshot() }); }, SNAPSHOT);

function handleConnection(ws) {
  if (clients.size >= MAX_PLAYERS && room.mode !== 'lobby') { send(ws, { type: 'error', message: 'Partita già piena.' }); ws.close(); return; }
  const id = 'P' + nextClientId++;
  if (!hostId) hostId = id;
  const client = { id, ws, name: id, ready: false, primary: 'pistol', secondary: 'shortsword', hat: 'none', input: defaultInput(), player: null };
  clients.set(id, client);
  send(ws, { type: 'hello', id, hostId, weapons: WEAPONS, enemies: ENEMY_TYPES, lobby: lobbyData() });
  broadcastLobby();

  ws.on('message', (raw) => {
    let msg; try { msg = JSON.parse(raw); } catch (_) { return; }
    const c = clients.get(id); if (!c) return;
    if (msg.type === 'setProfile') {
      c.name = cleanName(msg.name);
      c.primary = getWeapon(msg.primary).id;
      c.secondary = getWeapon(msg.secondary).id;
      c.hat = cleanHat(msg.hat);
      broadcastLobby();
    } else if (msg.type === 'ready') {
      c.ready = !!msg.ready;
      c.name = cleanName(msg.name || c.name);
      c.primary = getWeapon(msg.primary || c.primary).id;
      c.secondary = getWeapon(msg.secondary || c.secondary).id;
      c.hat = cleanHat(msg.hat || c.hat);
      broadcastLobby();
    } else if (msg.type === 'start') {
      if (id === hostId && room.mode === 'lobby') {
        const ok = startGame();
        if (!ok) send(ws, { type: 'error', message: 'Serve almeno 1 player pronto.' });
      }
    } else if (msg.type === 'input') {
      c.input = { up: !!msg.up, down: !!msg.down, left: !!msg.left, right: !!msg.right, active: msg.active === 1 ? 1 : 0 };
    } else if (msg.type === 'quit') {
      if (room.mode === 'playing' && c.player) { c.player.dead = true; }
    }
  });

  ws.on('close', () => {
    clients.delete(id);
    if (hostId === id) hostId = clients.keys().next().value || null;
    if (room.mode === 'playing') {
      if (activePlayers().length === 0) endGame(false, 'Tutti disconnessi o morti. LAN evaporata.');
    } else {
      broadcastLobby();
    }
  });
}

server.on('upgrade', handleUpgrade);

server.listen(PORT, '0.0.0.0', () => {
  console.log('BLACK / WHITE SURVIVOR 0.9A MOBILEMENUSFIT');
  console.log(`Server attivo su http://localhost:${PORT}`);
  console.log('Per altri PC nella stessa LAN: http://IP-DEL-PC-HOST:' + PORT);
});
