'use strict';

let lanWs = null;
let lanId = null;
let lanHostId = null;
let lanLobby = null;
let lanState = null;
let lanConnected = false;
let lanReady = false;
let lanPlaying = false;
let lanAnimationId = null;
let lanInput = { up: false, down: false, left: false, right: false, active: 0 };
let lanSeenEnemies = new Set();
let lanLastHudState = null;
let lanRunRewardClaimed = false;

function lanEl(id) { return document.getElementById(id); }
function lanSetMessage(text) { const node = lanEl('lanMessage'); if (node) node.textContent = text || ''; }
function lanStatus(text) { const node = lanEl('lanStatus'); if (node) node.textContent = text; }
function lanSend(msg) { if (lanWs && lanWs.readyState === WebSocket.OPEN) lanWs.send(JSON.stringify(msg)); }
function lanOwnPlayer() { return lanState?.players?.find(p => p.id === lanId) || null; }
function lanIsHost() { return lanId && lanHostId && lanId === lanHostId; }

function lanRenderLoadoutSelects() {
  const unlocked = WEAPONS.filter(w => hasWeapon(w.id));
  const options = unlocked.map(w => `<option value="${w.id}">${w.name} // ${w.rarity} // ${w.type}</option>`).join('');
  if (lanEl('lanPrimarySelect')) lanEl('lanPrimarySelect').innerHTML = options;
  if (lanEl('lanSecondarySelect')) lanEl('lanSecondarySelect').innerHTML = options;
  if (lanEl('lanPrimarySelect')) lanEl('lanPrimarySelect').value = hasWeapon(save.primary) ? save.primary : 'pistol';
  if (lanEl('lanSecondarySelect')) lanEl('lanSecondarySelect').value = hasWeapon(save.secondary) ? save.secondary : 'shortsword';
}


async function lanStartServerFromLauncher() {
  const port = String(lanEl('lanHostPortInput')?.value || '3000').trim() || '3000';
  const status = lanEl('lanServerStatus');
  if (status) status.textContent = 'Accensione server sulla porta ' + port + '...';
  try {
    const res = await fetch('/api/start-server', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ port })
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || 'launcher error');
    if (status) status.textContent = `Server acceso su porta ${data.port}. Host locale: http://localhost:${data.port}`;
    if (lanEl('lanGuestIpInput')) lanEl('lanGuestIpInput').value = location.hostname || 'localhost';
    if (lanEl('lanGuestPortInput')) lanEl('lanGuestPortInput').value = String(data.port);
    lanSetMessage('Server acceso. Ora premi CONNECT. I guest usano IP host + porta ' + data.port + '.');
  } catch (err) {
    if (status) status.textContent = 'Non posso accendere da qui. Avvia node launcher.js oppure node server.js ' + port;
    lanSetMessage('Il browser da solo non può avviare Node. Usa START_LANB.bat o node launcher.js.');
  }
}

async function lanStopServerFromLauncher() {
  const status = lanEl('lanServerStatus');
  try {
    const res = await fetch('/api/stop-server', { method: 'POST' });
    const data = await res.json();
    if (status) status.textContent = data.ok ? 'Server spento.' : 'Nessun server acceso dal launcher.';
  } catch (_) {
    if (status) status.textContent = 'Stop disponibile solo se stai usando node launcher.js.';
  }
}

function lanTargetHostPort() {
  let ip = (lanEl('lanGuestIpInput')?.value || 'localhost').trim() || 'localhost';
  let port = String(lanEl('lanGuestPortInput')?.value || lanEl('lanHostPortInput')?.value || '3000').trim() || '3000';
  ip = ip.replace(/^https?:\/\//, '').replace(/^wss?:\/\//, '').replace(/\/$/, '');
  if (ip.includes(':')) {
    const parts = ip.split(':');
    ip = parts[0] || 'localhost';
    port = parts[1] || port;
  }
  return { ip, port, host: `${ip}:${port}` };
}

function lanConnect() {
  if (lanWs && (lanWs.readyState === WebSocket.OPEN || lanWs.readyState === WebSocket.CONNECTING)) return;
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const target = lanTargetHostPort();
  const url = `${proto}//${target.host}`;
  lanStatus('Connessione a ' + url + ' ...');
  try {
    lanWs = new WebSocket(url);
  } catch (err) {
    lanStatus('Errore WebSocket. Accendi il server o controlla IP/porta.');
    return;
  }

  lanWs.addEventListener('open', () => {
    lanConnected = true;
    lanStatus('Connesso. Aspetta lobby...');
    lanSendProfile();
  });

  lanWs.addEventListener('message', (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch (_) { return; }
    if (msg.type === 'hello') {
      lanId = msg.id;
      lanHostId = msg.hostId;
      lanLobby = msg.lobby;
      lanStatus(`Connesso come ${lanId}${lanIsHost() ? ' // HOST' : ''}`);
      lanRenderLobby();
      lanSendProfile();
    } else if (msg.type === 'lobby') {
      lanLobby = msg.lobby;
      lanHostId = msg.lobby?.hostId || lanHostId;
      lanRenderLobby();
    } else if (msg.type === 'gameStart') {
      lanState = msg.state;
      lanPlaying = true;
      lanRunRewardClaimed = false;
      lanReady = false;
      lanSetMessage('Run LAN partita. Non morite in modo imbarazzante.');
      if (animationId) cancelAnimationFrame(animationId);
      if (game) { game.running = false; game = null; }
      showScreen('game');
      lanStartRenderLoop();
    } else if (msg.type === 'state') {
      lanState = msg.state;
      lanLastHudState = msg.state;
      lanDiscoverEnemiesFromState(msg.state);
    } else if (msg.type === 'gameOver') {
      lanPlaying = false;
      lanState = null;
      if (!lanRunRewardClaimed) {
        save.coins += Math.max(0, Math.floor(msg.coins || 0));
        lanRunRewardClaimed = true;
        saveGame();
      }
      lanShowGameOver(msg);
    } else if (msg.type === 'error') {
      lanSetMessage(msg.message || 'Errore LAN.');
    }
  });

  lanWs.addEventListener('close', () => {
    lanConnected = false;
    lanPlaying = false;
    lanStatus('Disconnesso. Controlla IP/porta o riaccendi il server.');
    lanRenderLobby();
  });
}

function lanDisconnect() {
  if (lanWs) lanWs.close();
  lanWs = null;
  lanConnected = false;
  lanPlaying = false;
  lanId = null;
  lanLobby = null;
  lanStatus('Disconnesso.');
  lanRenderLobby();
}

function lanSendProfile() {
  if (!lanConnected) return;
  lanSend({
    type: 'setProfile',
    name: lanEl('lanNameInput')?.value || 'Player',
    primary: lanEl('lanPrimarySelect')?.value || save.primary || 'pistol',
    secondary: lanEl('lanSecondarySelect')?.value || save.secondary || 'shortsword',
    hat: save.hat || 'none'
  });
}

function lanToggleReady() {
  if (!lanConnected) { lanSetMessage('Prima devi connetterti al server LAN.'); return; }
  lanReady = !lanReady;
  lanSend({
    type: 'ready',
    ready: lanReady,
    name: lanEl('lanNameInput')?.value || 'Player',
    primary: lanEl('lanPrimarySelect')?.value || 'pistol',
    secondary: lanEl('lanSecondarySelect')?.value || 'shortsword',
    hat: save.hat || 'none'
  });
  lanEl('lanReadyBtn').textContent = lanReady ? 'UNREADY' : 'READY';
}

function lanStartHost() {
  if (!lanConnected) { lanSetMessage('Non sei connesso.'); return; }
  if (!lanIsHost()) { lanSetMessage('Solo il primo connesso può premere START HOST.'); return; }
  lanSend({ type: 'start' });
}

function lanRenderLobby() {
  const box = lanEl('lanLobbyList');
  if (!box) return;
  if (!lanLobby || !lanLobby.players || lanLobby.players.length === 0) {
    box.innerHTML = '<p>Vuota.</p>';
  } else {
    box.innerHTML = lanLobby.players.map(p => {
      const primary = getWeapon(p.primary);
      const secondary = getWeapon(p.secondary);
      return `<div class="lan-player-line ${p.id === lanId ? 'me' : ''}">
        <b>${p.host ? 'HOST ' : ''}${p.name}</b>
        <span>${p.ready ? 'READY' : 'NOT READY'}</span>
        <small>${primary.name} + ${secondary.name}</small>
      </div>`;
    }).join('');
  }
  const startBtn = lanEl('lanStartBtn');
  if (startBtn) startBtn.disabled = !lanIsHost();
  if (lanConnected) lanStatus(`Connesso come ${lanId || '?'}${lanIsHost() ? ' // HOST' : ''}`);
}

function lanSendInput() {
  if (!lanPlaying || !lanConnected) return;
  lanSend({ type: 'input', ...lanInput });
}

function lanStartRenderLoop() {
  if (lanAnimationId) cancelAnimationFrame(lanAnimationId);
  const tick = () => {
    if (lanPlaying && lanState) lanDrawState(lanState);
    lanAnimationId = requestAnimationFrame(tick);
  };
  lanAnimationId = requestAnimationFrame(tick);
}

function lanDiscoverEnemiesFromState(state) {
  if (!state?.enemies) return;
  let changed = false;
  for (const e of state.enemies) {
    if (!save.discoveredEnemies.includes(e.id)) {
      save.discoveredEnemies.push(e.id);
      changed = true;
    }
    lanSeenEnemies.add(e.id);
  }
  if (changed) saveGame();
}

function lanUpdateHud(state) {
  const p = lanOwnPlayer();
  if (p) {
    const w1 = getWeapon(p.primary);
    const w2 = getWeapon(p.secondary);
    const active = p.activeWeaponIndex === 1 ? w2 : w1;
    lanEl('hudHp').textContent = `${Math.ceil(p.hp)} / ${p.maxHp}${p.dead ? ' DEAD' : ''}`;
    lanEl('hudMana').textContent = `${Math.floor(p.mana)} / ${p.maxMana}`;
    lanEl('hudActive').textContent = (p.activeWeaponIndex === 0 ? '1 ' : '2 ') + active.name;
    lanEl('hudPrimary').textContent = w1.name;
    lanEl('hudSecondary').textContent = w2.name;
    lanEl('hpBar').style.width = clamp(p.hp / p.maxHp * 100, 0, 100) + '%';
    lanEl('manaBar').style.width = p.maxMana ? clamp(p.mana / p.maxMana * 100, 0, 100) + '%' : '0%';
  } else {
    lanEl('hudHp').textContent = '-';
    lanEl('hudMana').textContent = '-';
    lanEl('hpBar').style.width = '0%';
    lanEl('manaBar').style.width = '0%';
  }
  lanEl('hudTime').textContent = formatTime(state.t || 0);
  lanEl('hudKills').textContent = state.kills || 0;
  lanEl('hudRunCoins').textContent = state.runCoins || 0;
}

function lanDrawState(state) {
  const canvas = lanEl('gameCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = false;
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  drawArenaDots(ctx, canvas);

  for (const p of state.projectiles || []) lanDrawProjectile(ctx, p);
  for (const b of state.enemyBullets || []) drawEnemyBullet(ctx, b);
  for (const e of state.enemies || []) lanDrawEnemy(ctx, e);
  for (const p of state.players || []) lanDrawEquippedWeapons(ctx, p, 'back');
  for (const p of state.players || []) lanDrawPlayer(ctx, p);
  for (const p of state.players || []) lanDrawEquippedWeapons(ctx, p, 'front');
  for (const fx of state.effects || []) lanDrawEffect(ctx, fx, state);
  lanUpdateHud(state);
}

function lanEnemyType(id) { return ENEMY_TYPES.find(e => e.id === id) || ENEMY_TYPES[0]; }
function lanEnemyPath(id) { return lanEnemyType(id).path; }
function lanWeaponPath(id) { return getWeapon(id).path; }

function lanDrawEnemy(ctx, e) {
  if (e.flash > 0) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(e.x - e.r, e.y - e.r, e.r * 2, e.r * 2);
  }
  const size = e.id === 'brute' ? 64 : e.id === 'crawler' ? 58 : e.id === 'spitter' ? 52 : 42;
  drawSprite(ctx, lanEnemyPath(e.id), e.x, e.y, size);
  const hpW = 32, hpH = 4;
  ctx.strokeStyle = '#FFFFFF';
  ctx.strokeRect(Math.round(e.x - hpW / 2), Math.round(e.y - size / 2 - 9), hpW, hpH);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(Math.round(e.x - hpW / 2), Math.round(e.y - size / 2 - 9), hpW * clamp(e.hp / e.maxHp, 0, 1), hpH);
}

function lanDrawPlayer(ctx, p) {
  ctx.save();
  if (p.dead) {
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(p.x - 10, p.y - 10); ctx.lineTo(p.x + 10, p.y + 10); ctx.moveTo(p.x + 10, p.y - 10); ctx.lineTo(p.x - 10, p.y + 10); ctx.stroke();
  } else {
    drawSprite(ctx, PLAYER_SPRITE, p.x, p.y, 32);
    const hat = getHat(p.hat);
    if (hat.path) drawSprite(ctx, hat.path, p.x, p.y + getHatY(hat.id), 32);
    if (p.id === lanId) {
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2;
      ctx.strokeRect(Math.round(p.x - 19), Math.round(p.y - 19), 38, 38);
    }
  }
  ctx.restore();
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '12px Consolas, monospace';
  ctx.fillText(p.name || p.id, Math.round(p.x - 18), Math.round(p.y - 26));
}

function lanDrawEquippedWeapons(ctx, p, layer = 'all') {
  if (p.dead) return;
  const baseAngle = p.displayAngle || 0;
  const sideAngle = baseAngle + Math.PI / 2;
  const weaponIds = [p.primary, p.secondary];
  for (let i = 0; i < weaponIds.length; i++) {
    const w = getWeapon(weaponIds[i]);
    const rw = p.weapons?.[i] || {};
    const active = i === p.activeWeaponIndex;
    if (layer === 'back' && active) continue;
    if (layer === 'front' && !active) continue;
    let angle = baseAngle;
    let forward = weaponGripDistance(w, active);
    let side = active ? 0 : (i === 0 ? -12 : 12);

    if (active) forward += 8;
    else forward -= 5;

    if (active && w.className === 'Slasher' && rw.swingTimer > 0 && rw.swingMax > 0) {
      const progress = 1 - (rw.swingTimer / rw.swingMax);
      const eased = 1 - Math.pow(1 - progress, 3);
      const dir = rw.swingDir || 1;
      const startArc = -1.15 * dir;
      const endArc = 1.05 * dir;
      angle = (rw.swingAngle || baseAngle) + startArc + (endArc - startArc) * eased;
      forward += 8 + Math.sin(progress * Math.PI) * 14;
      side += Math.cos(progress * Math.PI) * 8 * dir;
    }

    const x = p.x + Math.cos(baseAngle) * forward + Math.cos(sideAngle) * side;
    const y = p.y + Math.sin(baseAngle) * forward + Math.sin(sideAngle) * side;
    const size = weaponVisualSize(w, active);
    const rot = angle + (w.className === 'Slasher' ? Math.PI / 4 : 0);

    if (w.id === 'twinknives') {
      const activeSide = rw.activeTwinSide || 1;
      const pulse = active && rw.swingTimer > 0 ? Math.sin((1 - rw.swingTimer / (rw.swingMax || 0.16)) * Math.PI) * 16 : 0;
      const leftX = x + Math.cos(sideAngle) * 14 + Math.cos(baseAngle) * (activeSide === 1 ? pulse : 0);
      const leftY = y + Math.sin(sideAngle) * 14 + Math.sin(baseAngle) * (activeSide === 1 ? pulse : 0);
      const rightX = x - Math.cos(sideAngle) * 14 + Math.cos(baseAngle) * (activeSide === -1 ? pulse : 0);
      const rightY = y - Math.sin(sideAngle) * 14 + Math.sin(baseAngle) * (activeSide === -1 ? pulse : 0);
      drawSprite(ctx, w.path, leftX, leftY, size, rot + 0.55, false);
      drawSprite(ctx, w.path, rightX, rightY, size, rot - 0.55, true);
    } else {
      drawSprite(ctx, w.path, x, y, size, rot, false);
    }
  }
}

function lanDrawProjectile(ctx, p) {
  const w = getWeapon(p.weaponId);
  if (p.orb) {
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.stroke();
    drawSprite(ctx, w.path, p.x, p.y, projectileVisualSize({ weaponId: p.weaponId }) + 8, p.angle);
    return;
  }
  drawSprite(ctx, w.path, p.x, p.y, projectileVisualSize({ weaponId: p.weaponId }), p.angle);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(Math.round(p.x - 2), Math.round(p.y - 2), 4, 4);
}

function lanDrawEffect(ctx, fx, state) {
  const alpha = clamp(fx.life / fx.maxLife, 0, 1);
  if (alpha < 0.45 && fx.type !== 'orbitScythe' && fx.type !== 'frenzySaw') return;
  ctx.save();
  ctx.strokeStyle = '#FFFFFF';
  ctx.fillStyle = '#FFFFFF';
  ctx.lineWidth = 3;
  if (fx.type === 'hit') {
    ctx.strokeRect(Math.round(fx.x - 8), Math.round(fx.y - 8), 16, 16);
  } else if (fx.type === 'coinpop') {
    ctx.fillRect(Math.round(fx.x - 5), Math.round(fx.y - 5 - (1 - alpha) * 12), 10, 10);
  } else if (fx.type === 'manaReward') {
    ctx.beginPath();
    ctx.arc(Math.round(fx.x), Math.round(fx.y - (1 - alpha) * 10), 8, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillRect(Math.round(fx.x - 2), Math.round(fx.y - 2 - (1 - alpha) * 10), 4, 4);
  } else if (fx.type === 'healReward') {
    const y = Math.round(fx.y - (1 - alpha) * 10);
    ctx.fillRect(Math.round(fx.x - 8), y - 2, 16, 4);
    ctx.fillRect(Math.round(fx.x - 2), y - 8, 4, 16);
  } else if (fx.type === 'runeEcho') {
    ctx.translate(fx.x, fx.y);
    ctx.rotate(fx.angle);
    ctx.strokeRect(Math.round(fx.range * 0.20), -10, Math.round(fx.range * 0.68), 20);
    ctx.beginPath(); ctx.arc(0, 0, fx.range, -0.45, 0.45); ctx.stroke();
  } else if (fx.type === 'zap') {
    ctx.beginPath();
    ctx.moveTo(Math.round(fx.x1), Math.round(fx.y1));
    ctx.lineTo(Math.round((fx.x1 + fx.x2) / 2 + 8), Math.round((fx.y1 + fx.y2) / 2 - 8));
    ctx.lineTo(Math.round(fx.x2), Math.round(fx.y2));
    ctx.stroke();
  } else if (fx.type === 'pulse') {
    ctx.beginPath(); ctx.arc(Math.round(fx.x), Math.round(fx.y), fx.radius || 48, 0, Math.PI * 2); ctx.stroke();
  } else if (fx.type === 'slash') {
    ctx.translate(fx.x, fx.y); ctx.rotate(fx.angle); ctx.beginPath(); ctx.arc(0, 0, fx.range, -0.65, 0.65); ctx.stroke();
  } else if (fx.type === 'twin') {
    ctx.translate(fx.x, fx.y); ctx.rotate(fx.angle); ctx.beginPath(); ctx.arc(0, 0, fx.range, -0.34, 0.34); ctx.stroke(); drawSprite(ctx, lanWeaponPath(fx.weaponId), fx.range * 0.72, fx.side * 10, 38, Math.PI / 4, fx.side < 0);
  } else if (fx.type === 'orbitScythe') {
    const owner = state.players.find(p => p.id === fx.owner);
    if (owner) {
      const progress = 1 - fx.life / fx.maxLife;
      const angle = fx.startAngle + progress * Math.PI * 2;
      const sx = owner.x + Math.cos(angle) * fx.range;
      const sy = owner.y + Math.sin(angle) * fx.range;
      ctx.beginPath(); ctx.arc(Math.round(owner.x), Math.round(owner.y), fx.range, 0, Math.PI * 2); ctx.stroke();
      drawSprite(ctx, lanWeaponPath(fx.weaponId), sx, sy, 72, angle + Math.PI / 4);
    }
    } else if (fx.type === 'beam') {
    ctx.translate(fx.x, fx.y);
    ctx.rotate(fx.angle);
    ctx.strokeRect(0, -Math.max(2, fx.width / 2), fx.range, Math.max(4, fx.width));
    ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(fx.range, 0); ctx.stroke();
  } else if (fx.type === 'voidRift') {
    ctx.translate(fx.x, fx.y);
    ctx.rotate(fx.angle);
    ctx.strokeRect(0, -fx.width / 2, fx.range, fx.width);
    ctx.beginPath(); ctx.moveTo(0, -fx.width); ctx.lineTo(fx.range, fx.width); ctx.stroke();
  } else if (fx.type === 'ricochet') {
    ctx.beginPath();
    ctx.moveTo(Math.round(fx.x1), Math.round(fx.y1));
    ctx.lineTo(Math.round((fx.x1 + fx.x2) / 2), Math.round((fx.y1 + fx.y2) / 2 - 12));
    ctx.lineTo(Math.round(fx.x2), Math.round(fx.y2));
    ctx.stroke();
  } else if (fx.type === 'saw') {
    ctx.beginPath(); ctx.arc(Math.round(fx.x), Math.round(fx.y), fx.radius || 80, 0, Math.PI * 2); ctx.stroke();
    drawSprite(ctx, lanWeaponPath(fx.weaponId), fx.x + Math.cos(fx.angle) * (fx.radius || 80) * 0.55, fx.y + Math.sin(fx.angle) * (fx.radius || 80) * 0.55, 64, fx.angle + Math.PI / 4);
  } else if (fx.type === 'frenzyStart') {
    ctx.beginPath(); ctx.arc(Math.round(fx.x), Math.round(fx.y), fx.radius || 72, 0, Math.PI * 2); ctx.stroke();
    ctx.strokeRect(Math.round(fx.x - 28), Math.round(fx.y - 28), 56, 56);
  } else if (fx.type === 'frenzySaw') {
    const owner = state.players.find(p => p.id === fx.owner);
    if (owner) {
      const progress = 1 - fx.life / fx.maxLife;
      const angle = progress * Math.PI * 10;
      ctx.beginPath(); ctx.arc(Math.round(owner.x), Math.round(owner.y), fx.range || 110, 0, Math.PI * 2); ctx.stroke();
      drawSprite(ctx, lanWeaponPath(fx.weaponId), owner.x + Math.cos(angle) * (fx.range || 110), owner.y + Math.sin(angle) * (fx.range || 110), 74, angle + Math.PI / 4);
    }
  } else if (fx.type === 'playerHit') {
    ctx.beginPath(); ctx.arc(fx.x, fx.y, 22, 0, Math.PI * 2); ctx.stroke();
  } else if (fx.type === 'playerDead') {
    ctx.beginPath(); ctx.arc(fx.x, fx.y, 32, 0, Math.PI * 2); ctx.stroke();
  } else if (fx.type === 'line') {
    ctx.translate(fx.x, fx.y); ctx.rotate(fx.angle); ctx.strokeRect(0, -fx.width / 2, fx.range, fx.width); drawSprite(ctx, lanWeaponPath(fx.weaponId), fx.range * 0.55, 0, 42, 0);
  }
  ctx.restore();
}

function lanShowGameOver(msg) {
  if (lanAnimationId) cancelAnimationFrame(lanAnimationId);
  lanEl('modalTitle').textContent = 'LAN RUN OVER';
  lanEl('modalText').textContent = `${msg.text} Kills: ${msg.kills}. Team coins earned: ${msg.coins}.`;
  lanEl('modal').classList.remove('hidden');
}

function lanBind() {
  lanRenderLoadoutSelects();
  document.querySelectorAll('[data-open="lan"]').forEach(btn => btn.addEventListener('click', () => {
    lanRenderLoadoutSelects();
    if (lanEl('lanGuestIpInput') && (!lanEl('lanGuestIpInput').value || lanEl('lanGuestIpInput').value === 'localhost')) lanEl('lanGuestIpInput').value = location.hostname || 'localhost';
    lanRenderLobby();
  }));
  lanEl('lanStartServerBtn')?.addEventListener('click', lanStartServerFromLauncher);
  lanEl('lanStopServerBtn')?.addEventListener('click', lanStopServerFromLauncher);
  lanEl('lanConnectBtn')?.addEventListener('click', lanConnect);
  lanEl('lanDisconnectBtn')?.addEventListener('click', lanDisconnect);
  lanEl('lanReadyBtn')?.addEventListener('click', lanToggleReady);
  lanEl('lanStartBtn')?.addEventListener('click', lanStartHost);
  lanEl('lanNameInput')?.addEventListener('change', lanSendProfile);
  lanEl('lanPrimarySelect')?.addEventListener('change', lanSendProfile);
  lanEl('lanSecondarySelect')?.addEventListener('change', lanSendProfile);

  window.addEventListener('keydown', e => {
    if (!lanPlaying) return;
    const key = e.key.toLowerCase();
    if (key === 'w' || key === 'arrowup') lanInput.up = true;
    if (key === 's' || key === 'arrowdown') lanInput.down = true;
    if (key === 'a' || key === 'arrowleft') lanInput.left = true;
    if (key === 'd' || key === 'arrowright') lanInput.right = true;
    if (key === '1') lanInput.active = 0;
    if (key === '2') lanInput.active = 1;
    if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) e.preventDefault();
    lanSendInput();
  });
  window.addEventListener('keyup', e => {
    if (!lanPlaying) return;
    const key = e.key.toLowerCase();
    if (key === 'w' || key === 'arrowup') lanInput.up = false;
    if (key === 's' || key === 'arrowdown') lanInput.down = false;
    if (key === 'a' || key === 'arrowleft') lanInput.left = false;
    if (key === 'd' || key === 'arrowright') lanInput.right = false;
    lanSendInput();
  });
  setInterval(lanSendInput, 50);
  lanEl('endRunBtn')?.addEventListener('click', () => {
    if (lanPlaying) {
      lanSend({ type: 'quit' });
      lanSetMessage('Hai quittato la run LAN. Drammatico ma valido.');
    }
  });
}

lanBind();
