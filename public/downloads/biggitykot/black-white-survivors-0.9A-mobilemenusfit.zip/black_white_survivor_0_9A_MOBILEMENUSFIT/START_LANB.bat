@echo off
title Black White Survivor LANB 0.5B Launcher
cd /d "%~dp0"
echo Avvio launcher LANB 0.5B...
echo Apri il browser su http://localhost:2999 se non si apre da solo.
start "" http://localhost:2999
node launcher.js
pause
