BLACK / WHITE SURVIVOR - LANB 0.5B manafix

Versione: LANB 0.5B manafix

CONTENUTO NUOVO
- Speller abilities:
  * Rune Sword: Rune Echo, secondo taglio runico dopo lo swing.
  * Mana Bolt: Arc Jump, il colpo salta su un nemico vicino.
  * White Orb: Orb Pulse, ogni impatto crea una piccola onda ad area.
  * Ghost Scythe resta con spin + swing normale mentre aspetta lo spin.
- Weapon Tester:
  * Puoi testare qualsiasi arma, anche bloccata.
  * Non sblocca armi.
  * Non dà coins.
  * Usa un dummy fermo per vedere comportamento, danni e feeling.
- LAN più semplice:
  * Host sceglie porta.
  * Host preme ACCENDI SERVER.
  * Guest mette IP + porta e preme CONNECT.

COME GIOCARE SOLO
Apri index.html nel browser e usa PLAY SOLO.

COME USARE LA LAN SEMPLIFICATA
Metodo consigliato su Windows:
1. Estrai lo ZIP.
2. Doppio click su START_LANB.bat.
3. Si apre il launcher su http://localhost:2999.
4. Vai su LAN CO-OP.
5. Scegli la porta, per esempio 3000.
6. Premi ACCENDI SERVER.
7. Premi CONNECT.
8. Gli altri computer aprono http://IP-DEL-PC-HOST:2999 oppure il file index.html, poi mettono IP host + porta 3000 e premono CONNECT.

Metodo terminale:
1. Apri terminale nella cartella.
2. Lancia: node launcher.js
3. Apri: http://localhost:2999
4. Usa ACCENDI SERVER dalla schermata LAN.

Metodo vecchio ancora valido:
node server.js 3000
Poi apri http://localhost:3000

COMANDI
WASD / Frecce = movimento
1 = arma primaria
2 = arma secondaria

NOTE
Il browser da solo non può avviare un processo Node. Per questo ACCENDI SERVER funziona quando la pagina è servita dal launcher: node launcher.js oppure START_LANB.bat.

Mana non si rigenera passivamente: 75% chance di recuperarlo quando uccidi un nemico.
25% chance di recuperare un po' di vita quando uccidi un nemico.


BLACK / WHITE SURVIVOR 0.6BB
- Aggiunte 6 armi epiche:
  War Halberd, Ricochet Gun, Void Katana, Rune Laser, Meat Saw, Blood Rifle.
- Le Speller epiche hanno ability uniche:
  Void Katana = Void Rift.
  Rune Laser = Rune Burn.
- Le Killer epiche hanno Frenzy:
  Meat Saw = Meat Storm.
  Blood Rifle = Blood Barrage.
- Le Killer fanno ancora autodanno pari al 25% del danno causato.
- Le Epiche sono nel gacha Black Box e nel Weapon Tester.
- Mana: niente rigenerazione passiva, recupero da kill con chance.

0.6B FIX:
- Rune Laser, Meat Saw e Blood Rifle spostate un po' più fuori dal player.
- Rune Laser, Meat Saw e Blood Rifle ridotte come presenza visiva in mano.
- Meat Saw ora fa danno costante da vicino come vera chainsaw.


0.6B
- Nuovo sprite player.
- Menu CHARACTER con selezione cappelli.
- Cappelli visibili in single player e LAN.


0.9A MOBILEFIT
- I cappelli non coprono più l'intero player.
- Ora stanno sopra il giocatore e lo coprono solo di circa 2-3 pixel.

0.9A MOBILEFIT
- Added temporary Character hat Y slider.
- Export JSON uses hat image center relative to player center, positive Y down.
- Slider will be removed after final JSON positions are confirmed.

0.9A MOBILEFIT
- Removed temporary hat Y slider/export.
- Applied final hat Y positions from JSON: hat -14, crown -18, monster -21, number1 -26, soldier -7, wizard -27.

0.9A MOBILEFIT
- Unselected weapon is drawn behind the player.
- Selected weapon is drawn in front and slightly farther from the player.

0.9A MOBILEFIT
- Weapon Tester: added dummy enemy selector.
- Dummy uses selected enemy sprite, radius and HP, but does not move or attack.
- Dummy respawns at the start point if killed or pushed outside the arena.

0.9A MOBILEFIT
- Fixed tester dummy damage visibility/death reset.
- Added live Weapon Tester controls in the in-game HUD.
- You can switch test weapon and dummy enemy without leaving the test.

0.9A MOBILEFIT
- Enemy HP increased globally.
- Crawler HP 12 -> 35.
- Runner HP 8 -> 28.
- Brute HP 60 -> 150.
- Spitter HP 22 -> 70.
- Weapon Tester dummies use these higher HP values too.

0.9A MOBILEFIT
- Bigger 1280x720 arena.
- Wave system: normal waves require kills and show a progress bar.
- Boss every 10 waves: Mitra-Spitter, Chained Beast of Tartarus, Gargamosh, Massive OverPowered BioMechanical Beast of Destruction, Perses.
- Boss HP bar integrated in the top wave bar.
- Boss waves end when the boss HP reaches zero.
- Perses fights alone: no normal enemy spawns in his boss wave.
- After wave 50, bosses loop in buffed tiers.
- Between-wave shop: temporary run points, free weapon changes, paid character upgrades.
- Extra slot offers up to 4 total weapon slots.
- Enemy kills grant temporary run points; coins remain permanent run rewards.

0.9A MOBILEFIT
- Restored rarity CSS class mapping: Comune/Raro/Epico/Leggendario.
- Rare blue, Epic purple, Legendary orange borders/tags are visible again.

0.9A MOBILEFIT
- Shop upgrades now apply stronger and visible runtime effects: damage, attack speed, speed, HP, mana, heal, knockback.
- Upgrade totals are shown in the between-wave shop stats line.
- Removed small HP bars above normal enemies and bosses.
- Boss HP is shown only by the large top boss bar during boss waves.

0.9A MOBILEFIT
- Auto aim/auto fire removed in main game and Weapon Tester.
- Mouse/pointer now controls aiming direction.
- Hold left click to shoot or attack; Space/Enter also fire in current aim direction.
- Active and inactive weapons are drawn farther from the player pivot so they do not overlap the body.
- Faster wave progression: lower enemy goals, faster spawns, earlier enemy variety.

0.9A MOBILEFIT
- Unselected weapon is now drawn directly behind the player at player center.
- Unselected weapon does not rotate with aim; it stays at a fixed 45 degree angle.
- Selected weapon stays far from the player center and rotates with aim/manual fire.

0.9A MOBILEFIT
- Selected weapon moved a little closer to the player center while still rotating with aim.
- Unselected weapon behavior unchanged: directly behind player, fixed 45 degrees.

0.9A MOBILEFIT
- Unselected weapon behind the player now keeps normal visual size instead of being reduced.
- Revolver visual size increased significantly.
- Pistol and Pebble Gun received a small visual size increase too, so shooters read better.

0.9A MOBILEFIT
- Auto aim restored: player aims at nearest enemy automatically.
- Auto shoot restored: active weapon fires automatically when a valid target exists.
- Weapon size/position fixes from previous builds kept.

0.9A MOBILEFIT
- Weapon/Dummy live controls are force-hidden outside Weapon Tester.
- Wave completion now shows a pre-shop banner: "Wave Completata!" or "Boss Wave Completata!".
- Shop opens after a short banner delay.
- Boss Rush dev mode added: one boss stage after another.
- Dev access: press TAB and enter hellofriend.
- Dev mode persists until Reset Save, gives effectively infinite coins, unlocks weapons and the full encyclopedia.
- Bosses are now tracked in the encyclopedia as seen/fought.
- Coin rewards reduced globally while points/shop progression remain separate.
- Wave completion does not refill mana; Refill Mana remains a meaningful shop option.

0.9A MOBILEFIT
- Boss Rush button is no longer shown directly from saved devMode.
- Press TAB and type hellofriend in the current session to reveal DEV: BOSS RUSH on the title/menu screen.
- DevMode rewards/unlocks still persist until Reset Save.
- Boss Rush now starts with a preparation shop before the first boss.
- Boss Rush grants prep points before boss fights; normal game is unchanged.
- Boss Rush slot offers are always available while slots remain.

0.9A MOBILEFIT
- Gargamosh clones now have a hard cap of 3 living clones.
- Chained Beast of Tartarus buffed: higher HP/speed/damage, stronger slam, chain pull, faster radial pressure.
- Boss Rush now fully restores player HP and Mana after each boss wave.
- Wave shop now shows player stats: HP, Mana, Speed, Damage, Attack Speed, Slots and Active weapon.

0.9A MOBILEFIT
- BioMechanical Beast reworked as preparation for the final boss.
- Increased speed heavily and improved boss pressure.
- Added laser ray sweeps with collision.
- Added denser bullet-hell rings and spiral patterns.
- BioMechanical now teaches movement/pattern reading before Perses.

0.9A MOBILEFIT
- Dev mode is session-only. It is disabled on every boot and is not injected into the save file.
- Press TAB to open the code prompt; type hellofriend to activate dev mode for the current session.
- Boss Rush button appears only after session dev access is activated.
- Killer weapon self-damage reduced from 25% to 12%.
- Mana now regenerates slowly during combat.
- In Boss Rush, on death the player may retry from the boss wave they lost to.

0.9A MOBILEFIT
- Fixed possible lock/freeze after defeating Chained Beast of Tartarus.
- Wave shop stats container changed from <p> to <div> because it now contains structured player stat blocks.
- Boss defeat transition now clears leftover combat entities more aggressively.
- Wave shop render is guarded so a UI render hiccup cannot leave the game stuck after a boss kill.

0.9A MOBILEFIT
- Hardened Gargamosh death transition.
- Gargamosh clone callbacks now abort safely if the boss is dead or the wave is no longer combat.
- Boss death now clears leftover visual effects too, not only enemies/projectiles.
- Added safety caps for enemy bullets and visual effects to prevent long fights from locking the browser.
- Delayed actions are cleared when leaving combat.

0.9A MOBILEFIT
- Dev mode no longer uses a prompt.
- Dev mode activates only by typing hellofriend on the title/menu screen.
- DEV: BOSS RUSH stays hidden until the session dev code is typed.
- Boss Rush now lets you choose the starting boss wave: 10, 20, 30, 40 or 50.
- Dev mode remains session-only and is not saved.

0.9A MOBILEFIT
- Fixed occasional stuck movement by clearing input on blur, screen changes, shop transitions and boss-wave transitions.
- During boss stages, auto aim/auto shoot prioritizes the boss.
- If a non-boss enemy is very close to the player, the player temporarily targets that close threat.
- BioMechanical Beast damage reduced: lower base damage, lower bullet damage and lower laser damage.

0.9A MOBILEFIT
- Fixed possible lock after defeating BioMechanical Beast.
- Root cause: if an orbit/frenzy/projectile effect killed a boss, finishWave cleared effects/projectiles while the same update loop kept reading them.
- updateEffects, updateOrbitScythe, updateFrenzySaw and updateProjectiles now abort safely when boss death changes the wave phase.
- Scheduled Blood Rifle frenzy shots also abort outside combat.

0.9A MOBILEFIT
- Perses reworked as a true final boss and not just another boss.
- Giant top-screen stationary eldritch turret.
- HP, size and visual presence massively increased.
- Adds simultaneous bullet crown rings, aimed fans, void rain and giant laser patterns.
- Adds huge vertical laser pillars and final-phase cross lasers.
- BioMechanical Beast is now clearly only the preparation for Perses.

0.9A MOBILEFIT
- Perses moved slightly lower on screen so the player can see the boss better.
- Perses visual size increased from 560 to 640.
- Perses collision/radius adjusted to match the bigger body.
- Perses laser/pulse origins adjusted to match the new lower body position.

0.9A MOBILEFIT
- Player power now creates enemy counter-upgrades.
- Boss HP/damage and enemy HP/damage/speed scale from player upgrades, slots and weapon power.
- Late-game high-power runs spawn more enemies and faster waves.
- If the player dies, they can retry from the current wave.
- Boss Rush no longer refills HP/Mana after every boss.
- Shop no longer offers full Mana refill; Heal 60 HP stays.
- Shop can offer +60 Max HP and +60 Max Mana as rare/boss-wave offers.
- Killer HP sustain now works only when the selected active weapon is Killer.
- Wave shop now allows one Black Box x1 pull per shop using coins.

0.9A MOBILEFIT
- Fixed particles/effects/projectiles lingering forever in Weapon Tester.
- Cause: safety guards added for boss death transitions stopped updateEffects/updateProjectiles when wavePhase was not combat; tester mode had no wavePhase.
- Tester mode now has wavePhase = combat and combat update guards explicitly allow tester mode.
- Switching tester weapon/enemy now clears projectiles, effects, enemy bullets, delayed actions and pickups.

0.9A MOBILEFIT
- Added mobile/APK touch controls.
- Left virtual joystick moves the player.
- Right buttons select weapon slots 1/2/3/4.
- Joystick input is separate from keyboard state and does not simulate WASD.
- Touch input is reset on blur, visibility change and screen transitions to avoid stuck movement.
- Mobile overlay is shown only on coarse pointer/touch devices.

0.9A MOBILEFIT
- Fixed Android/APK menu scroll blocked by the mobile input patch.
- Removed global touch-action:none from html/body.
- Menu and non-game screens now allow vertical touch scrolling.
- Game canvas and mobile controls still block touch scroll/zoom while playing.
- showScreen now toggles body.game-input-lock only when the game screen is active.

0.9A MOBILEFIT
- Game screen now fits phone landscape without page scroll.
- Topbar is hidden during gameplay on mobile/APK.
- HUD/stats are compact and placed above the stage.
- Canvas scales inside the remaining viewport while keeping 16:9.
- Mobile joystick/buttons are reduced in landscape so they cover less of the stage.

--- 0.9A MOBILEICON ---
Aggiunte icone del sito/app: favicon 32x32, icona 512x512, apple-touch-icon 180x180 e manifest web app landscape.


--- 0.9A LANGUAGEPOLISH ---
- Added language selector: IT / EN.
- Title/version presentation cleaned: version shown as 0.9A only.
- Renamed the slot-offer label to Extra Slot.
- Reworked several menu, shop, tester, death, and weapon texts to sound cleaner and more game-like.

--- 0.9A POSTPERSESCOLOR ---
- After Wave 50 / Perses, normal enemies can spawn as colored variants.
- Green = HP boosted, Red = attack boosted, Purple = attack speed boosted, Yellow = movement speed boosted, Blue = defense / damage reduction boosted.

--- 0.9A DESCFIX ---
- Weapon, enemy, and boss descriptions now switch between Italian and English.
- Weapon ability text now follows the selected language when available.

0.9A MOBILEWEBFIT
- Fixed phone web gameplay scale: the game screen now locks to the visible mobile viewport instead of becoming too large.
- On touch devices, gameplay hides the topbar, places a compact HUD above the stage, and sizes the canvas to fit the remaining landscape space.
- Menus remain scrollable; only active gameplay is fixed/no-scroll.


0.9A MOBILEMENUSHOPFIX
- Mobile title/menu layout made more compact and readable.
- In-run shop Black Box now uses Run Coins instead of persistent saved coins, so pulls work during a run.


0.9A MOBILEMENUSFIT
- Mobile non-game screens now behave like app screens.
- Encyclopedia remains the only scrollable mobile menu.
- Loadout, Character, LAN, Gacha and Weapon Tester use compressed mobile layouts.
