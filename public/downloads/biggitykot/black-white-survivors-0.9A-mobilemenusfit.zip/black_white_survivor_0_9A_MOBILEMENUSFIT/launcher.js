'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const LAUNCHER_PORT = Number(process.env.LAUNCHER_PORT || 2999);
const ROOT = __dirname;
let gameServer = null;
let gamePort = null;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.txt': 'text/plain; charset=utf-8',
  '.json': 'application/json; charset=utf-8'
};

function sendJson(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise(resolve => {
    let body = '';
    req.on('data', chunk => { body += chunk; if (body.length > 10000) req.destroy(); });
    req.on('end', () => resolve(body));
  });
}

function startGameServer(port) {
  if (gameServer && gamePort === port) return { ok: true, port, already: true };
  if (gameServer) {
    try { gameServer.kill(); } catch (_) {}
    gameServer = null;
  }
  gamePort = port;
  gameServer = spawn(process.execPath, ['server.js', String(port)], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe']
  });
  gameServer.stdout.on('data', d => process.stdout.write('[game] ' + d.toString()));
  gameServer.stderr.on('data', d => process.stderr.write('[game-error] ' + d.toString()));
  gameServer.on('exit', () => { gameServer = null; gamePort = null; });
  return { ok: true, port, already: false };
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST,GET,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' });
      res.end();
      return;
    }

    if (req.method === 'POST' && req.url === '/api/start-server') {
      const body = await readBody(req);
      let data = {};
      try { data = JSON.parse(body || '{}'); } catch (_) {}
      const port = Number(data.port || 3000);
      if (!Number.isInteger(port) || port < 1024 || port > 65535 || port === LAUNCHER_PORT) {
        sendJson(res, 400, { ok: false, error: 'Porta non valida o uguale al launcher.' });
        return;
      }
      sendJson(res, 200, startGameServer(port));
      return;
    }

    if (req.method === 'POST' && req.url === '/api/stop-server') {
      if (gameServer) {
        try { gameServer.kill(); } catch (_) {}
        gameServer = null;
        gamePort = null;
        sendJson(res, 200, { ok: true });
      } else {
        sendJson(res, 200, { ok: false, error: 'Nessun server acceso dal launcher.' });
      }
      return;
    }

    if (req.method === 'GET' && req.url === '/api/status') {
      sendJson(res, 200, { ok: true, running: !!gameServer, port: gamePort });
      return;
    }

    const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
    const cleanPath = urlPath === '/' ? '/index.html' : urlPath;
    const filePath = path.normalize(path.join(ROOT, cleanPath));
    if (!filePath.startsWith(ROOT)) { res.writeHead(403); res.end('Forbidden'); return; }
    fs.readFile(filePath, (err, data) => {
      if (err) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream' });
      res.end(data);
    });
  } catch (err) {
    sendJson(res, 500, { ok: false, error: String(err.message || err) });
  }
});

server.listen(LAUNCHER_PORT, '0.0.0.0', () => {
  console.log('BLACK / WHITE SURVIVOR LANB 0.5B LAUNCHER');
  console.log(`Apri: http://localhost:${LAUNCHER_PORT}`);
  console.log('Da lì usa LAN CO-OP > ACCENDI SERVER.');
});
